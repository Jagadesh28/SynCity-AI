import { useState } from "react";
import { Line, Bar, Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, useGLTF } from "@react-three/drei";

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, BarElement, ArcElement, Tooltip, Legend);

function CampusModel() {
  const { scene } = useGLTF("/Sincityui.glb"); // Make sure this file is in /public
  return scene ? <primitive object={scene} scale={1.5} /> : null;
}

export default function App() {
  const [activeTab, setActiveTab] = useState("Overview");

  return (
    <div className="w-screen h-screen flex bg-gradient-to-br from-[#0a0f1c] via-[#0f172a] to-black text-white overflow-hidden">

      {/* Sidebar */}
      <div className="w-64 p-6 backdrop-blur-xl bg-white/5 border-r border-white/10">
        <h1 className="text-2xl font-bold mb-10 tracking-wide bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
          Syncity AI
        </h1>
        <div className="space-y-3">
          {["Overview", "Energy", "Water", "Waste", "Security"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`w-full text-left px-4 py-3 rounded-xl transition-all duration-300 ${
                activeTab === tab
                  ? "bg-cyan-500/20 border border-cyan-400 text-cyan-300 shadow-lg shadow-cyan-500/20"
                  : "hover:bg-white/10 text-gray-300"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-10 overflow-auto">

        {/* Header */}
        <div className="flex justify-between items-center mb-10">
          <div>
            <h2 className="text-2xl font-semibold tracking-wide">
              Smart Campus AI Command Center
            </h2>
            <p className="text-sm text-gray-400 mt-1">
              Real-time Optimization & Monitoring
            </p>
          </div>
          <div className="text-xs px-4 py-2 rounded-full bg-red-500/10 border border-red-500/30 text-red-400">
            Powered by AMD Ryzen AI
          </div>
        </div>

        {/* ================= OVERVIEW ================= */}
        {activeTab === "Overview" && (
          <div className="grid grid-cols-3 gap-6">
            {[
              { title: "Energy Usage", value: "5.8 MW", status: "Optimal" },
              { title: "Water Consumption", value: "170 KL", status: "Moderate" },
              { title: "Waste Collected", value: "900 kg", status: "Stable" },
            ].map((item, index) => (
              <div key={index} className="p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-lg">
                <h4 className="text-sm text-gray-400">{item.title}</h4>
                <p className="text-2xl font-bold mt-2">{item.value}</p>
                <div className="mt-3 text-xs text-cyan-400">{item.status}</div>
                <div className="mt-4 h-2 bg-white/10 rounded-full overflow-hidden">
                  <div className="h-2 bg-cyan-400 w-[70%]"></div>
                </div>
              </div>
            ))}

            <div className="col-span-3 h-[450px] rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-xl">
              <Canvas camera={{ position: [0, 5, 10] }}>
                <ambientLight intensity={1} />
                <directionalLight position={[5, 5, 5]} />
                <OrbitControls />
                <CampusModel />
              </Canvas>
            </div>
          </div>
        )}

        {/* ================= ENERGY ================= */}
        {activeTab === "Energy" && (
          <div className="grid grid-cols-2 gap-8">
            <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-cyan-400/20 shadow-lg">
              <h3 className="text-cyan-400 mb-6 text-lg">Energy Forecast</h3>
              <Line
                data={{
                  labels: ["1PM", "2PM", "3PM", "4PM", "5PM", "6PM"],
                  datasets: [
                    {
                      data: [4800, 5200, 5500, 6000, 6200, 5800],
                      borderColor: "#22d3ee",
                      tension: 0.4,
                    },
                  ],
                }}
              />
            </div>

            <div className="p-6 rounded-2xl bg-green-500/10 border border-green-400/20 shadow-lg">
              <h3 className="text-green-400 text-lg mb-4">AI Conservation Insight</h3>
              <p className="text-gray-300 text-sm">
                Reduce HVAC load in Block B during peak hours. Predicted 8% reduction in power usage.
              </p>
              <div className="mt-6">
                <div className="text-xs text-gray-400">Estimated Monthly Savings</div>
                <div className="text-2xl font-bold text-green-400">₹1,35,000</div>
              </div>
            </div>
          </div>
        )}

{/* ================= WATER ================= */}
{activeTab === "Water" && (
  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">

    {[
      { name: "Hostel", data: [120, 130, 125, 200, 128, 135, 140], color: "#3b82f6", threshold: 150 },
      { name: "Block A", data: [80, 85, 82, 88, 90, 87, 85], color: "#10b981", threshold: 100 },
      { name: "Canteen", data: [50, 55, 52, 60, 53, 58, 57], color: "#f59e0b", threshold: 65 },
      { name: "Labs", data: [30, 28, 32, 31, 29, 35, 33], color: "#ef4444", threshold: 40 },
    ].map((building, index) => {
      // Check if any day exceeds threshold
      const leakDetected = building.data.some((value) => value > building.threshold);
      
      return (
        <div key={index} className="bg-white/5 backdrop-blur-xl border border-cyan-400/20 shadow-lg p-6 rounded-2xl">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-cyan-400 text-lg">{building.name} - Daily Water Usage (KL)</h3>
            <div className={`text-sm font-semibold ${leakDetected ? "text-red-400" : "text-green-400"}`}>
              {leakDetected ? "⚠ Leak Detected" : "Normal"}
            </div>
          </div>
          <Line
            data={{
              labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
              datasets: [{
                label: `${building.name} Usage`,
                data: building.data,
                borderColor: building.color,
                backgroundColor: `${building.color}33`, // transparent fill
                tension: 0.3,
              }]
            }}
            options={{
              plugins: {
                legend: { display: true, labels: { color: "white" } },
              },
              scales: {
                x: { ticks: { color: "white" } },
                y: { ticks: { color: "white" }, beginAtZero: true }
              }
            }}
          />
        </div>
      )
    })}

    {/* Tank Level */}
    <div className="bg-white/5 backdrop-blur-xl border border-teal-400/20 shadow-lg p-6 rounded-2xl md:col-span-2">
      <h3 className="text-teal-400 mb-4 text-lg">Tank Level</h3>
      <div className="w-64 mx-auto">
        <Doughnut
          data={{
            labels: ["Used", "Available"],
            datasets: [{ data: [65, 35], backgroundColor: ["#06b6d4", "#1e293b"] }]
          }}
        />
      </div>
    </div>
  </div>
)}

        {/* ================= WASTE ================= */}
        {activeTab === "Waste" && (
          <div className="grid grid-cols-2 gap-8">
            <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-green-400/20 shadow-lg">
              <h3 className="text-green-400 mb-6 text-lg">Waste Collected</h3>
              <Bar
                data={{
                  labels: ["Hostel", "Academic", "Canteen", "Ground"],
                  datasets: [{ data: [300, 200, 250, 150], backgroundColor: "#22c55e" }],
                }}
              />
            </div>
            <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-yellow-400/20 shadow-lg">
              <h3 className="text-yellow-400 mb-6 text-lg">Waste Segregation</h3>
              <div className="w-64 mx-auto">
                <Doughnut
                  data={{
                    labels: ["Organic", "Plastic", "Paper", "Metal"],
                    datasets: [{ data: [45, 25, 20, 10], backgroundColor: ["#16a34a", "#3b82f6", "#eab308", "#f97316"] }],
                  }}
                />
              </div>
            </div>
          </div>
        )}

        {/* ================= SECURITY ================= */}
        {activeTab === "Security" && (
          <div className="grid grid-cols-2 gap-8">
            <div className="p-6 rounded-2xl bg-red-500/10 border border-red-500/30 shadow-lg">
              <h3 className="text-red-400 mb-4 text-lg">Campus Threat Level</h3>
              <div className="text-4xl font-bold">LOW</div>
              <div className="mt-4 text-gray-400 text-sm">No active intrusion detected.</div>
            </div>
            <div className="p-6 rounded-2xl bg-white/5 backdrop-blur-xl border border-white/10 shadow-lg">
              <h3 className="text-cyan-400 mb-6 text-lg">Access Attempts (6h)</h3>
              <Bar
                data={{
                  labels: ["Gate 1", "Gate 2", "Lab", "Hostel"],
                  datasets: [{ data: [24, 18, 12, 30], backgroundColor: "#f43f5e" }],
                }}
              />
            </div>
          </div>
        )}

      </div>
    </div>
  );
}