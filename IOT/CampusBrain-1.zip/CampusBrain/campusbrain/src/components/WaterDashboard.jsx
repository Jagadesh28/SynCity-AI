// WaterDashboard.js
import { Line, Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend);

export default function WaterDashboard() {
  const waterUsagePerPlace = {
    labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    datasets: [
      { label: "Hostel", data: [20, 21, 19, 40, 22, 21, 20], borderColor: "#ef4444", backgroundColor: "rgba(239,68,68,0.2)", tension: 0.3 },
      { label: "Academic Block", data: [15, 16, 15, 16, 15, 16, 15], borderColor: "#f97316", backgroundColor: "rgba(249,115,22,0.2)", tension: 0.3 },
      { label: "Canteen", data: [18, 19, 18, 20, 19, 18, 17], borderColor: "#eab308", backgroundColor: "rgba(234,179,8,0.2)", tension: 0.3 },
      { label: "Labs", data: [12, 12, 13, 25, 12, 12, 12], borderColor: "#22c55e", backgroundColor: "rgba(34,197,94,0.2)", tension: 0.3 },
    ],
  };

  const tankLevelData = {
    labels: ["Used", "Available"],
    datasets: [{ data: [65, 35], backgroundColor: ["#0ea5e9", "#1e293b"] }],
  };

  return (
    <div className="p-6 space-y-8 text-white">
      <div className="bg-slate-800 p-4 rounded-xl md:col-span-2">
        <h3 className="mb-4 text-xl font-semibold">Weekly Water Usage by Place</h3>
        <Line data={waterUsagePerPlace} options={{ responsive: true, plugins: { tooltip: { mode: "index", intersect: false }, legend: { position: "top" } }, scales: { y: { beginAtZero: true, title: { display: true, text: "Water Usage (KL)" } } } }} />
      </div>
      <div className="bg-slate-800 p-4 rounded-xl md:col-span-2">
        <h3 className="mb-4 text-xl font-semibold">Tank Level Status</h3>
        <div className="w-64 mx-auto">
          <Doughnut data={tankLevelData} />
        </div>
      </div>
    </div>
  );
}