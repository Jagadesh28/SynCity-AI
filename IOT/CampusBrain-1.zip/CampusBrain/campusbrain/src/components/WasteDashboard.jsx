import { Bar, Doughnut } from "react-chartjs-2";

export default function WasteDashboard() {
  const wasteCollectionData = {
    labels: ["Hostel", "Academic Block", "Canteen", "Ground"],
    datasets: [
      {
        label: "Waste Collected (kg)",
        data: [300, 200, 250, 150],
        backgroundColor: "#22c55e",
      },
    ],
  };

  const segregationData = {
    labels: ["Organic", "Plastic", "Paper", "Metal"],
    datasets: [
      {
        data: [45, 25, 20, 10],
        backgroundColor: ["#16a34a", "#3b82f6", "#eab308", "#f97316"],
      },
    ],
  };

  return (
    <div className="p-6 space-y-8 text-white">
      <h2 className="text-3xl font-bold">♻ Waste Management</h2>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-slate-800 p-4 rounded-xl">
          <h3 className="mb-4">Waste Collected by Zone</h3>
          <Bar data={wasteCollectionData} />
        </div>

        <div className="bg-slate-800 p-4 rounded-xl">
          <h3 className="mb-4">Waste Segregation Ratio</h3>
          <div className="w-64 mx-auto">
            <Doughnut data={segregationData} />
          </div>
        </div>
      </div>
    </div>
  );
}